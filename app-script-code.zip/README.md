# MyGP সার্ভে অ্যাপ্লিকেশন

পেশাভিত্তিক MyGP ব্যবহার সার্ভে এবং রিপোর্টিং সিস্টেম

## 📋 প্রজেক্ট সম্পর্কে

এই অ্যাপ্লিকেশনটি বিভিন্ন পেশার মানুষদের MyGP অ্যাপ ব্যবহার সম্পর্কে সার্ভে পরিচালনা এবং রিপোর্ট তৈরি করার জন্য ডিজাইন করা হয়েছে।

## 🚀 ফিচারসমূহ

- ✅ সহজ এবং আকর্ষণীয় সার্ভে ফর্ম
- 📊 রিয়েল-টাইম ড্যাশবোর্ড এবং চার্ট
- 📈 পেশাভিত্তিক বিস্তারিত রিপোর্ট
- 📥 এক্সেল রিপোর্ট ডাউনলোড
- 🔄 Google Sheets এর সাথে সিঙ্ক
- 💾 লোকাল স্টোরেজ সাপোর্ট (অফলাইন)
- 🔄 অটো-রিফ্রেশ (প্রতি ৩০ সেকেন্ডে)
- 📱 মোবাইল রেসপন্সিভ ডিজাইন

## 📁 প্রজেক্ট স্ট্রাকচার

```
mygp-survey/
│
├── index.html              # মূল HTML ফাইল
├── README.md              # ডকুমেন্টেশন
├── app-script-code.txt    # Google Apps Script কোড
│
├── css/
│   └── style.css          # কাস্টম CSS স্টাইল
│
├── js/
│   ├── app.js             # মূল JavaScript লজিক
│   └── config.js          # কনফিগারেশন (optional)
│
└── assets/
    ├── bclgroup-lgoo.png  # BCL Group লোগো
    └── Grameenphone_Logo.png  # Grameenphone লোগো
```

## 🛠️ টেকনোলজি

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Custom styling with animations
- **JavaScript (ES6+)** - Modern JavaScript
- **Bootstrap 5.3** - Responsive framework
- **Bootstrap Icons** - Icon library
- **Chart.js** - Data visualization
- **SheetJS (xlsx)** - Excel file generation

### Backend
- **Google Apps Script** - Server-side logic
- **Google Sheets** - Data storage

### Fonts
- **SolaimanLipi** - Bengali font support

## 📦 ইনস্টলেশন

### 1. লোকাল সেটআপ

```bash
# প্রজেক্ট ক্লোন করুন
git clone <repository-url>

# প্রজেক্ট ডিরেক্টরিতে যান
cd mygp-survey

# যেকোনো লোকাল সার্ভার দিয়ে চালান
# উদাহরণ: Live Server, XAMPP, WAMP, Laragon ইত্যাদি
```

### 2. Google Sheets সেটআপ

1. Google Sheets এ নতুন স্প্রেডশিট তৈরি করুন
2. `Extensions` > `Apps Script` এ যান
3. `app-script-code.txt` থেকে কোড কপি করে পেস্ট করুন
4. `Deploy` > `New deployment` ক্লিক করুন
5. `Web app` সিলেক্ট করুন
6. `Who has access` এ `Anyone` সিলেক্ট করুন
7. Web App URL কপি করুন

### 3. কনফিগারেশন

`js/app.js` ফাইলে Google Script URL আপডেট করুন:

```javascript
const GOOGLE_SCRIPT_URL = "আপনার_Google_Script_URL_এখানে_পেস্ট_করুন";
```

## 💡 ব্যবহারবিধি

### সার্ভে ফর্ম
1. **নাম** - সার্ভে অংশগ্রহণকারীর নাম লিখুন
2. **ফোন নম্বর** - ফোন নম্বর প্রবেশ করুন (ক্লিক করলে স্বয়ংক্রিয়ভাবে "88" যুক্ত হবে)
3. **পেশা** - ড্রপডাউন থেকে পেশা নির্বাচন করুন
4. **MyGP ব্যবহার** - হ্যাঁ/না সিলেক্ট করুন
5. **কারণ** - "হ্যাঁ" সিলেক্ট করলে কারণ নির্বাচন করতে হবে
6. **সাবমিট** - ফর্ম সাবমিট করুন

### ড্যাশবোর্ড
- মোট সার্ভেকৃত সংখ্যা দেখুন
- MyGP ব্যবহারকারীর সংখ্যা দেখুন
- পেশাভিত্তিক চার্ট দেখুন
- ব্যবহারের কারণ চার্ট দেখুন

### রিপোর্ট
- প্রতিটি পেশার জন্য আলাদা রিপোর্ট দেখুন
- পেশাভিত্তিক বিস্তারিত তথ্য এক্সেল ডাউনলোড করুন

### এক্সেল ডাউনলোড
- **সকল এন্ট্রি ডাউনলোড** - এন্ট্রি পেজে রিফ্রেশ বাটনের পাশের সবুজ বাটন
- **পেশাভিত্তিক রিপোর্ট** - রিপোর্ট ট্যাবে প্রতিটি পেশার কার্ডে ক্লিক করুন
- **সামগ্রিক রিপোর্ট** - ফ্লোটিং ডাউনলোড বাটন (নিচে ডানে)

## ⚙️ কনফিগারেশন অপশন

### Auto-refresh
`js/app.js` ফাইলে auto-refresh interval পরিবর্তন করুন:

```javascript
autoRefreshInterval = setInterval(function() {
    loadFromGoogleSheets(false);
}, 30000); // মিলিসেকেন্ডে (30000 = 30 seconds)
```

### পেশার তালিকা
প্রয়োজনে পেশার তালিকা যোগ/সম্পাদনা করুন:
- `index.html` - Form select options
- `js/app.js` - `generateProfessionReports()` ফাংশন

## 🎨 কাস্টমাইজেশন

### রঙ পরিবর্তন
`css/style.css` ফাইলে CSS variables আপডেট করুন:

```css
:root {
    --primary-color: #00b0f0;
    --gp-blue: #00b0f0;
    --bcl-green: #00a651;
    --gradient: linear-gradient(135deg, #00b0f0 0%, #0088cc 100%);
}
```

### ফন্ট পরিবর্তন
`index.html` এ ফন্ট লিংক পরিবর্তন করুন এবং `css/style.css` এ `font-family` আপডেট করুন।

## 📱 রেসপন্সিভ ডিজাইন

- ডেস্কটপ (1400px+) - Full features
- ট্যাবলেট (768px-1399px) - Adjusted layout
- মোবাইল (<768px) - Compact view

## 🐛 ট্রাবলশুটিং

### ডেটা লোড হচ্ছে না
1. ইন্টারনেট সংযোগ চেক করুন
2. Google Script URL সঠিক আছে কিনা যাচাই করুন
3. Google Apps Script deployment সঠিক আছে কিনা দেখুন
4. Browser console (F12) চেক করুন

### Excel ডাউনলোড কাজ করছে না
1. SheetJS library লোড হয়েছে কিনা চেক করুন
2. Browser console এ error আছে কিনা দেখুন
3. Data আছে কিনা নিশ্চিত করুন

## 🔒 সিকিউরিটি

- Google Sheets এ sensitive data সংরক্ষণের ক্ষেত্রে সতর্কতা অবলম্বন করুন
- Production এ deploy করার আগে access permissions যাচাই করুন
- নিয়মিত data backup রাখুন

## 📞 সাপোর্ট

সমস্যা বা প্রশ্নের জন্য যোগাযোগ করুন:
- **Developer**: Arman Azij
- **Facebook**: [fb.com/armanaazij](https://fb.com/armanaazij)

## 📄 লাইসেন্স

This project is developed for BCL Group and Grameenphone survey purposes.

## 🙏 স্বীকৃতি

- **BCL Group** - Project sponsor
- **Grameenphone** - Brand partnership
- **Bootstrap Team** - UI Framework
- **Chart.js Team** - Charting library
- **SheetJS Team** - Excel generation

---

**Version**: 2.0  
**Last Updated**: November 2025  
**Status**: ✅ Production Ready
